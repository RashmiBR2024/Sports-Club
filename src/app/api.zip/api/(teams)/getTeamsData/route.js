import { NextResponse } from "next/server";
import connectdb from "@/app/db/mongodb";
import TeamModel from "@/app/models/teams/schema";

const corsMiddleware = (handler) => (req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
    res.setHeader("Access-Control-Allow-Headers", "Origin, Content-Type, X-Amz-Date, Authorization, X-Amz-Security-Token, locale");
    res.setHeader("Access-Control-Allow-Credentials", "true");

    if (req.method === "OPTIONS") {
        return res.status(200).end();
    }

    return handler(req, res);
};

const xkey = process.env.API_AUTH_KEY;

export const GET = async (req) => {
    try {
        // Get the 'name' query parameter using nextUrl.searchParams
        const name = req.nextUrl.searchParams.get('name'); // Extract 'name' from the query params

        // Construct the filter object based on 'name' query parameter
        const filters = {};
        if (name) filters.name = { $regex: name, $options: 'i' };  // Case-insensitive search by name

        // Connect to the database
        await connectdb();

        // Fetch teams based on 'name' filter without pagination
        const teams = await TeamModel.find(filters).sort({ createYear: -1 }); // Sort teams by creation year in descending order

        // Return the response with teams
        return NextResponse.json({
            success: true,
            data: teams,
        });
    } catch (error) {
        console.error("Error:", error);
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    }
};

export default corsMiddleware(async (req, res) => {
    if (req.method === "GET") {
        return GET(req, res);
    }
    return NextResponse.json({ success: false, message: "Method Not Allowed" }, { status: 405 });
});

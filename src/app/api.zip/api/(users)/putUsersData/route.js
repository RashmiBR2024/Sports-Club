import { NextResponse } from "next/server";
import connectdb from "@/app/db/mongodb";
import UserModel from "@/app/models/users/schema";

const xkey = process.env.API_AUTH_KEY;

export const PUT = async (req) => {
    console.log("PUT REQUEST");

    try {
        // Get headers directly from req.headers (for API routes)
        const reqApiKey = req.headers.get("x-api-key");  // API key from headers
        const gXkey = req.nextUrl.searchParams.get("authkey"); // Query param key

        // Check if either of the keys match the expected API key
        if (xkey !== reqApiKey && xkey !== gXkey) {
            return NextResponse.json({ success: false, error: "Invalid API Auth Key" }, { status: 403 });
        }

        // Parse the request body for updated data
        const { _id, ...updatedData } = await req.json(); // Extract _id from the body and the rest as updated data

        // Check if _id is present in the body
        if (!_id) {
            return NextResponse.json({ success: false, error: "User ID is required in the body" }, { status: 400 });
        }

        console.log("Updated Data Received:", updatedData);

        // Connect to the database
        await connectdb();

        // Find the user by ID and update their data using `$set`
        const updatedUser = await UserModel.findByIdAndUpdate(
            _id,  // Use the _id directly from the request body
            { $set: updatedData },  // Use `$set` to update specific fields
            { new: true }  // Return the updated document after modification
        );

        if (!updatedUser) {
            return NextResponse.json({ success: false, error: "User not found" }, { status: 404 });
        }

        // Respond with the updated user data
        return NextResponse.json({ success: true, data: updatedUser }, { status: 200 });
    } catch (error) {
        console.error("Error:", error);
        // Respond with error message if something goes wrong
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    }
};

export default async (req) => {
    const method = req.method;

    if (method === "PUT") {
        return PUT(req);
    }

    return NextResponse.json({ success: false, message: "Method Not Allowed" }, { status: 405 });
};
